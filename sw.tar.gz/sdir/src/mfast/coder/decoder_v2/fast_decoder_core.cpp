// required for MSVC when building DLL
#include "fast_decoder_core.h"